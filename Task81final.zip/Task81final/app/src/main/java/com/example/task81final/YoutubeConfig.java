package com.example.task81final;

public class YoutubeConfig {
    public YoutubeConfig()
    {

    }

    private static final String API_KEY = "AIzaSyCISs62HkUl7AymqC4s1JPkG2CfCIDaSAg";

    public static String getApiKey() {
        return API_KEY;
    }
}
