package com.example.task81final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class MainActivity2 extends AppCompatActivity {

    YouTubePlayerView youtube;
    private static final String TAG = "MainActivity";
    YouTubePlayer.OnInitializedListener onInitializedListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String shortlist = intent.getStringExtra("shortstring");
        Log.d(TAG, "onCreate: Starting.");

        youtube = findViewById(R.id.youtube);


        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                Log.d(TAG, "onCreate: Done initializing");
                youTubePlayer.loadVideo(shortlist);

            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

                Log.d(TAG, "onClick: Failed to initialize");
            }


        };
        youtube.initialize(YoutubeConfig.getApiKey(), onInitializedListener);

    }
}